***********************************************************
ЗАГРУЖЕНО С САЙТА DASHONE.RU
Macintosh 128K rev 1.0
Credits:
Murmulator pico-mac https://murmulator.ru/pico-mac
Pico-umac original port https://github.com/evansm7/pico-mac
Murmulator port by Mike V73 https://t.me/Michael_V1973
ОБНОВЛЕНИЕ МОДЕЛИ от 02.06.25
***********************************************************